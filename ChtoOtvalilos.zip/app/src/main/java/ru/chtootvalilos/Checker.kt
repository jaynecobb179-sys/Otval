package ru.chtootvalilos

import android.annotation.SuppressLint
import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.telephony.TelephonyManager
import java.io.IOException
import java.net.ConnectException
import java.net.HttpURLConnection
import java.net.InetSocketAddress
import java.net.Socket
import java.net.SocketTimeoutException
import java.net.URL
import java.net.UnknownHostException
import java.security.SecureRandom
import java.security.cert.X509Certificate
import java.util.concurrent.Callable
import java.util.concurrent.Executors
import java.util.concurrent.Future
import javax.net.ssl.SNIHostName
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLException
import javax.net.ssl.SSLSocket
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager

object Checker {
    private const val UA =
        "Mozilla/5.0 (Linux; Android 16; SM-S938B) AppleWebKit/537.36 Chrome/130 Mobile Safari/537.36"
    private val RU = listOf("https://ya.ru", "https://www.gosuslugi.ru")
    private val FOREIGN = listOf(
        "https://cp.cloudflare.com/generate_204",
        "https://www.gstatic.com/generate_204",
        "https://www.apple.com/library/test/success.html"
    )
    private const val PING_URL = "https://cp.cloudflare.com/generate_204"
    private const val DL_URL = "https://speed.cloudflare.com/__down?bytes=400000"
    private const val DL_BYTES = 400000L

    private val pool = Executors.newCachedThreadPool()
    private fun <T> bg(f: () -> T): Future<T> = pool.submit(Callable { f() })

    private class Http(
        val ok: Boolean, val code: Int, val ms: Int, val bytes: Long,
        val err: String?, val stalled: Boolean
    )

    private class Srv(
        val tcpOk: Boolean, val tcpMs: Int, val tcpErr: String?,
        val tlsTried: Boolean, val tlsOk: Boolean, val tlsErr: String?,
        val bytes: Long, val stalled: Boolean, val tlsMs: Int
    )

    // ---------- низкоуровневые проверки ----------

    private fun errText(e: Throwable): String = when (e) {
        is SocketTimeoutException -> "таймаут"
        is UnknownHostException -> "DNS: имя не найдено"
        is ConnectException -> "соединение отклонено / нет маршрута"
        is SSLException -> "TLS сброшен (${e.message?.take(40) ?: ""})"
        else -> e.javaClass.simpleName + (e.message?.let { ": " + it.take(40) } ?: "")
    }

    private fun ms(t0: Long): Int = ((System.nanoTime() - t0) / 1_000_000).toInt()

    /** net == null -> обычный маршрут (через VPN, если он включён). expect > 0 -> скачать столько байт. */
    private fun get(net: Network?, url: String, timeoutMs: Int, expect: Long): Http {
        val t0 = System.nanoTime()
        var c: HttpURLConnection? = null
        try {
            val u = URL(url)
            c = (if (net != null) net.openConnection(u) else u.openConnection()) as HttpURLConnection
            c.connectTimeout = timeoutMs
            c.readTimeout = timeoutMs
            c.instanceFollowRedirects = false
            c.useCaches = false
            c.setRequestProperty("User-Agent", UA)
            val code = c.responseCode
            val ttfb = ms(t0)
            if (expect > 0 && code in 200..299) {
                var total = 0L
                try {
                    val ins = c.inputStream
                    val buf = ByteArray(16384)
                    while (true) {
                        val n = ins.read(buf)
                        if (n < 0) break
                        total += n
                        if (total >= expect) break
                    }
                } catch (e: SocketTimeoutException) {
                    return Http(false, code, ms(t0), total, "завис после ${total / 1024} КБ", true)
                } catch (e: IOException) {
                    return Http(false, code, ms(t0), total, "обрыв после ${total / 1024} КБ", true)
                }
                val ok = total >= expect * 0.9
                return Http(ok, code, ms(t0), total, if (ok) null else "получено только ${total / 1024} КБ", false)
            }
            return Http(code in 200..399, code, ttfb, 0, null, false)
        } catch (e: Exception) {
            return Http(false, -1, ms(t0), 0, errText(e), false)
        } finally {
            try { c?.disconnect() } catch (ignored: Exception) {}
        }
    }

    private fun dns(net: Network, host: String): Int {
        val t0 = System.nanoTime()
        return try {
            net.getAllByName(host)
            ms(t0)
        } catch (e: Exception) {
            -1
        }
    }

    @SuppressLint("CustomX509TrustManager", "TrustAllX509TrustManager")
    private fun trustAllCtx(): SSLContext {
        val tm = object : X509TrustManager {
            override fun checkClientTrusted(chain: Array<X509Certificate>?, authType: String?) {}
            override fun checkServerTrusted(chain: Array<X509Certificate>?, authType: String?) {}
            override fun getAcceptedIssuers(): Array<X509Certificate> = arrayOf()
        }
        val c = SSLContext.getInstance("TLS")
        c.init(null, arrayOf<TrustManager>(tm), SecureRandom())
        return c
    }

    /** TCP + TLS(SNI) + чтение ответа напрямую (мимо VPN) — ловит «заморозку после ~16 КБ». */
    private fun serverTest(net: Network, host: String, port: Int, sni: String): Srv {
        val t0 = System.nanoTime()
        val sock: Socket = try {
            val addr = net.getByName(host)
            val so = net.socketFactory.createSocket()
            try {
                so.connect(InetSocketAddress(addr, port), 6000)
            } catch (e: Exception) {
                try { so.close() } catch (ignored: Exception) {}
                throw e
            }
            so
        } catch (e: Exception) {
            return Srv(false, 0, errText(e), false, false, null, 0, false, 0)
        }
        val tcpMs = ms(t0)
        if (sni.isBlank()) {
            try { sock.close() } catch (ignored: Exception) {}
            return Srv(true, tcpMs, null, false, false, null, 0, false, 0)
        }
        try {
            val t1 = System.nanoTime()
            val ssl = trustAllCtx().socketFactory.createSocket(sock, sni, port, true) as SSLSocket
            val p = ssl.sslParameters
            p.serverNames = listOf(SNIHostName(sni))
            ssl.sslParameters = p
            ssl.soTimeout = 7000
            ssl.startHandshake()
            val tlsMs = ms(t1)
            val out = ssl.outputStream
            out.write(
                ("GET / HTTP/1.1\r\nHost: $sni\r\nUser-Agent: $UA\r\nAccept: */*\r\nConnection: close\r\n\r\n")
                    .toByteArray()
            )
            out.flush()
            var total = 0L
            val buf = ByteArray(16384)
            val ins = ssl.inputStream
            try {
                while (total < 200_000) {
                    val n = ins.read(buf)
                    if (n < 0) break
                    total += n
                }
            } catch (e: IOException) {
                return Srv(true, tcpMs, null, true, true, null, total, total > 0, tlsMs)
            }
            return Srv(true, tcpMs, null, true, true, null, total, false, tlsMs)
        } catch (e: Exception) {
            return Srv(true, tcpMs, null, true, false, errText(e), 0, false, 0)
        } finally {
            try { sock.close() } catch (ignored: Exception) {}
        }
    }

    @Suppress("DEPRECATION")
    private fun pickRaw(cm: ConnectivityManager): Network? {
        fun isRaw(n: Network): Boolean {
            val c = cm.getNetworkCapabilities(n) ?: return false
            return !c.hasTransport(NetworkCapabilities.TRANSPORT_VPN) &&
                c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
        }
        val active = cm.activeNetwork
        if (active != null && isRaw(active)) return active
        val cands = cm.allNetworks.filter { isRaw(it) }
        return cands.firstOrNull {
            cm.getNetworkCapabilities(it)?.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) == true
        } ?: cands.firstOrNull()
    }

    private fun median(l: List<Int>): Int = if (l.isEmpty()) 0 else l.sorted()[l.size / 2]
    private fun fmt(x: Int) = if (x >= 0) "$x мс" else "ошибка"
    private fun hostOf(u: String) = URL(u).host.removePrefix("www.")
    private fun res(h: Http) = if (h.ok) "${h.ms} мс" else (h.err ?: "HTTP ${h.code}")

    private fun serverAdvice(s: Srv, adv: MutableList<String>) {
        when {
            !s.tcpOk -> adv.add(
                "Адрес вашего сервера недоступен с этой сети (${s.tcpErr}), хотя другие зарубежные сайты открываются — " +
                    "значит заблокирован IP или порт. Смените порт (443, 8443, 2053…) или IP/хостера."
            )
            s.tlsTried && !s.tlsOk -> adv.add(
                "TCP до сервера проходит, но TLS-рукопожатие рвётся — DPI режет по SNI/отпечатку. " +
                    "Смените SNI, fingerprint (chrome/firefox/randomized) или транспорт (xHTTP, Hysteria2, AmneziaWG)."
            )
            s.stalled -> adv.add(
                "Соединение с вашим сервером «замерзает» после нескольких КБ — классическая заморозка VLESS+Reality. " +
                    "Нужен другой транспорт (xHTTP, Hysteria2, AmneziaWG), другой порт и SNI либо новый IP."
            )
        }
    }

    // ---------- главный прогон ----------

    fun run(ctx: Context): Report {
        val cm = ctx.getSystemService(ConnectivityManager::class.java)
        val warnMs = Store.warnMs(ctx)
        val now = System.currentTimeMillis()
        val rows = ArrayList<Row>()
        val adv = ArrayList<String>()

        val active = cm.activeNetwork
        val vpn = active?.let {
            cm.getNetworkCapabilities(it)?.hasTransport(NetworkCapabilities.TRANSPORT_VPN)
        } == true

        val raw = pickRaw(cm)
        if (raw == null) {
            rows.add(Row("Сеть", Lvl.FAIL, "Нет подключения к интернету"))
            adv.add("Проверьте режим полёта, Wi‑Fi и мобильные данные, баланс SIM. Попробуйте переключиться между Wi‑Fi и мобильной сетью.")
            return Report(State.RED, "Нет сети", 0, vpn, rows, adv, now)
        }

        val caps = cm.getNetworkCapabilities(raw)
        val kind = when {
            caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true -> "Wi‑Fi"
            caps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true -> {
                val op = try {
                    ctx.getSystemService(TelephonyManager::class.java)?.networkOperatorName ?: ""
                } catch (e: Exception) { "" }
                if (op.isBlank()) "Мобильная сеть" else "Мобильная сеть ($op)"
            }
            else -> "Сеть"
        }
        rows.add(Row("Сеть", Lvl.OK, "$kind • VPN ${if (vpn) "включён" else "выключен"}"))

        // параллельно: DNS, российские и зарубежные сайты напрямую, сервер
        val fDnsRu = bg { dns(raw, "ya.ru") }
        val fDnsFor = bg { dns(raw, "cloudflare.com") }
        val fRu = RU.map { it to bg { get(raw, it, 6000, 0) } }
        val fFor = FOREIGN.map { it to bg { get(raw, it, 6000, 0) } }
        val cfgHost = Store.host(ctx)
        val cfgPort = Store.port(ctx)
        val cfgSni = Store.sni(ctx)
        val fSrv = if (cfgHost.isNotBlank() && !vpn) bg { serverTest(raw, cfgHost, cfgPort, cfgSni) } else null

        val suffix = if (vpn) " (мимо VPN)" else ""

        val dRu = fDnsRu.get()
        val dFor = fDnsFor.get()
        val dnsOk = dRu >= 0 || dFor >= 0
        rows.add(
            when {
                dRu >= 0 && dFor >= 0 -> Row("DNS", Lvl.OK, "ya.ru ${fmt(dRu)}, cloudflare.com ${fmt(dFor)}")
                dnsOk -> Row("DNS", Lvl.WARN, "отвечает не на все имена (ya.ru: ${fmt(dRu)}, cloudflare.com: ${fmt(dFor)})")
                else -> Row("DNS", Lvl.FAIL, "имена не разрешаются")
            }
        )

        val ru = fRu.map { it.first to it.second.get() }
        val fo = fFor.map { it.first to it.second.get() }
        val ruOkN = ru.count { it.second.ok }
        val forOkN = fo.count { it.second.ok }
        // При включённом VPN Android запрещает привязывать сокеты к сети в обход VPN (EPERM).
        fun blocked(h: Http) = h.err?.contains("Binding socket") == true
        val rawBlocked = vpn && ru.all { blocked(it.second) } && fo.all { blocked(it.second) }
        if (rawBlocked) {
            rows.add(
                Row(
                    "Проверка мимо VPN", Lvl.SKIP,
                    "Android не даёт проверять сеть в обход включённого VPN. Чтобы отличить белый список от поломки сервера, выключите VPN и нажмите «Проверить»."
                )
            )
        } else {
            rows.add(
                Row(
                    "Российские сайты$suffix",
                    if (ruOkN > 0) Lvl.OK else Lvl.FAIL,
                    ru.joinToString(", ") { "${hostOf(it.first)}: ${res(it.second)}" }
                )
            )
            rows.add(
                Row(
                    "Зарубежные сайты$suffix",
                    when {
                        forOkN == fo.size -> Lvl.OK
                        forOkN > 0 -> Lvl.WARN
                        else -> Lvl.FAIL
                    },
                    fo.joinToString(", ") { "${hostOf(it.first)}: ${res(it.second)}" }
                )
            )
        }

        val srv = fSrv?.get()
        if (srv != null) {
            val target = "$cfgHost:$cfgPort"
            if (!srv.tcpOk) {
                rows.add(Row("Ваш сервер $target", Lvl.FAIL, "TCP не проходит: ${srv.tcpErr}"))
            } else {
                rows.add(Row("Ваш сервер $target", Lvl.OK, "TCP ${srv.tcpMs} мс"))
                if (srv.tlsTried) {
                    val kb = srv.bytes / 1024
                    rows.add(
                        when {
                            !srv.tlsOk -> Row("TLS / SNI $cfgSni", Lvl.FAIL, "рукопожатие не прошло: ${srv.tlsErr}")
                            srv.stalled -> Row("TLS / SNI $cfgSni", Lvl.FAIL, "завис после $kb КБ (признак DPI)")
                            srv.bytes >= 20000 -> Row("TLS / SNI $cfgSni", Lvl.OK, "ок, получено $kb КБ без зависания")
                            else -> Row("TLS / SNI $cfgSni", Lvl.OK, "рукопожатие ок, ответ короткий ($kb КБ)")
                        }
                    )
                }
            }
        } else {
            rows.add(
                Row(
                    "Ваш сервер", Lvl.SKIP,
                    if (cfgHost.isNotBlank()) "проверка работает только при выключенном VPN"
                    else "не задан — можно указать внизу экрана"
                )
            )
        }

        // VPN-туннель (обычный маршрут)
        var tunnelOk = false
        var tunnelStall = false
        var tunnelPing = 0
        if (vpn) {
            val pings = ArrayList<Int>()
            var pingErr = ""
            repeat(3) {
                val h = get(null, PING_URL, 8000, 0)
                if (h.ok) pings.add(h.ms) else pingErr = h.err ?: "HTTP ${h.code}"
            }
            if (pings.isEmpty()) {
                rows.add(Row("VPN-туннель", Lvl.FAIL, "нет ответа через VPN: $pingErr"))
            } else {
                tunnelPing = median(pings)
                val dl = get(null, DL_URL, 12000, DL_BYTES)
                tunnelOk = dl.ok
                tunnelStall = dl.stalled
                rows.add(
                    if (dl.ok) Row(
                        "VPN-туннель", if (tunnelPing > warnMs) Lvl.WARN else Lvl.OK,
                        "ответ $tunnelPing мс, 400 КБ за ${dl.ms} мс"
                    ) else Row(
                        "VPN-туннель", Lvl.FAIL,
                        "ответ $tunnelPing мс, но загрузка не идёт: ${dl.err ?: "HTTP ${dl.code}"}"
                    )
                )
            }
        } else {
            rows.add(Row("VPN-туннель", Lvl.SKIP, "VPN выключен"))
        }

        val okMs = fo.filter { it.second.ok }.map { it.second.ms }
        val ping = when {
            vpn && tunnelPing > 0 -> tunnelPing
            okMs.isNotEmpty() -> median(okMs)
            else -> median(ru.filter { it.second.ok }.map { it.second.ms })
        }

        val ruOk = ruOkN > 0 || rawBlocked
        val forOk = forOkN > 0 || rawBlocked
        val srvBad = srv != null && (!srv.tcpOk || (srv.tlsTried && !srv.tlsOk) || srv.stalled)

        val (state, head) = when {
            !ruOk && !forOk -> {
                if (!dnsOk) {
                    adv.add("DNS не отвечает. Попробуйте: Настройки → Подключения → Другие настройки → Частный DNS → указать dns.google или one.one.one.one; перезагрузить роутер; переключиться между Wi‑Fi и мобильной сетью.")
                } else {
                    adv.add("Не открываются ни российские, ни зарубежные сайты, хотя DNS отвечает: проблема на канале — у оператора или роутера. Перезагрузите роутер, переключитесь Wi‑Fi ↔ мобильная сеть, отключите режим «Блокировать подключения без VPN».")
                }
                State.RED to (if (!dnsOk) "DNS не работает" else "Интернета нет")
            }
            ruOk && !forOk && !(vpn && tunnelOk) -> {
                adv.add("Включён «белый список»: открываются только российские сервисы, зарубежные IP закрыты целиком. Никакой конфиг и протокол тут не поможет — это не поломка VPN.")
                adv.add("Что можно: подождать (режим обычно временный), перейти на Wi‑Fi или SIM другого оператора. Схемы обхода через маскировку под сайты из белого списка существуют, но быстро блокируются.")
                adv.add("Пока белый список — выключите VPN: он только расходует батарею и ничего не даёт.")
                State.BLACK to "Белый список: открываются только российские сайты"
            }
            vpn && tunnelStall -> {
                adv.add("Туннель «замерзает» после первых КБ — типичный признак DPI против VLESS+Reality: соединение устанавливается, но данные не идут.")
                adv.add("Смените транспорт: xHTTP, Hysteria2 (UDP), AmneziaWG; другой порт и SNI; другой хостер/IP. В Hiro/Happ выберите другой тип сервера или спросите поддержку, какие ноды сейчас живые.")
                if (srv != null) serverAdvice(srv, adv)
                State.RED to "Туннель «замерзает»"
            }
            vpn && !tunnelOk -> {
                adv.add("VPN включён, но трафик через него не идёт. Переключите сервер или протокол в клиенте, перезапустите VPN, обновите приложение и его ядро (Xray/sing-box).")
                adv.add("Если включено «Блокировать подключения без VPN» — на время диагностики выключите.")
                if (srv != null) serverAdvice(srv, adv)
                if (forOkN > 0) adv.add("Зарубежные сайты напрямую открываются, значит сеть в порядке — виноват именно выбранный сервер или протокол.")
                if (rawBlocked) adv.add("Выключите VPN и нажмите «Проверить» ещё раз: так станет видно, белый список это или проблема самого сервера.")
                State.RED to "VPN включён, но не работает"
            }
            else -> {
                val warn = ArrayList<String>()
                if (ping > warnMs) {
                    warn.add("медленно")
                    adv.add("Пинг высокий ($ping мс). Выберите ближайшую локацию или другую ноду, сравните Wi‑Fi и мобильную сеть — на одной из них может быть заметно быстрее. Высокий пинг часто означает троттлинг или перегруженный сервер.")
                }
                if (!ruOk) {
                    warn.add("ru")
                    adv.add("Российские сайты не открываются, а зарубежные — да. Это необычно: проверьте DNS и не завёрнут ли весь трафик в VPN с зарубежным выходом.")
                }
                if (!vpn && forOkN == 1) {
                    warn.add("часть")
                    adv.add("Часть зарубежных сайтов недоступна — возможна частичная блокировка. Следите за состоянием.")
                }
                if (!vpn && srvBad && srv != null) {
                    warn.add("srv")
                    serverAdvice(srv, adv)
                }
                if (vpn && tunnelOk && ruOk && !forOk) {
                    adv.add("Белый список включён, но ваш туннель через него проходит — пока работает, ничего менять не нужно.")
                }
                if (warn.isEmpty()) {
                    adv.add(if (vpn) "Всё хорошо, туннель работает." else "Всё хорошо. VPN выключен — зарубежные сайты открываются напрямую.")
                    State.GREEN to (if (vpn) "Всё работает через VPN" else "Всё работает")
                } else {
                    State.YELLOW to "Работает, но есть проблемы"
                }
            }
        }

        return Report(state, head, ping, vpn, rows, adv, now)
    }
}
