package ru.chtootvalilos

import android.content.Context

object Store {
    private fun p(c: Context) = c.getSharedPreferences("chto", Context.MODE_PRIVATE)

    fun saveReport(c: Context, r: Report) {
        p(c).edit().putString("rep", r.toJson()).apply()
    }

    fun loadReport(c: Context): Report? = p(c).getString("rep", null)?.let { Report.fromJson(it) }

    fun host(c: Context): String = p(c).getString("host", "") ?: ""
    fun port(c: Context): Int = p(c).getInt("port", 443)
    fun sni(c: Context): String = p(c).getString("sni", "") ?: ""
    fun warnMs(c: Context): Int = p(c).getInt("warn", 900)

    fun saveServer(c: Context, host: String, port: Int, sni: String, warn: Int) {
        p(c).edit().putString("host", host.trim()).putInt("port", port)
            .putString("sni", sni.trim()).putInt("warn", warn).apply()
    }
}
