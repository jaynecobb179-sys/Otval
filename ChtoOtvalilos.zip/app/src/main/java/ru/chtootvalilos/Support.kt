package ru.chtootvalilos

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import java.util.concurrent.TimeUnit

class CheckWorker(ctx: Context, p: WorkerParameters) : Worker(ctx, p) {
    override fun doWork(): Result {
        return try {
            val r = Checker.run(applicationContext)
            Store.saveReport(applicationContext, r)
            StatusWidget.updateAll(applicationContext)
            Result.success()
        } catch (e: Exception) {
            Result.success()
        }
    }
}

object Scheduler {
    fun ensure(c: Context) {
        val req = PeriodicWorkRequestBuilder<CheckWorker>(15, TimeUnit.MINUTES).build()
        WorkManager.getInstance(c)
            .enqueueUniquePeriodicWork("periodic", ExistingPeriodicWorkPolicy.KEEP, req)
    }

    fun checkSoon(c: Context, delaySec: Long) {
        val req = OneTimeWorkRequestBuilder<CheckWorker>()
            .setInitialDelay(delaySec, TimeUnit.SECONDS).build()
        WorkManager.getInstance(c)
            .enqueueUniqueWork("soon", ExistingWorkPolicy.REPLACE, req)
    }
}

/** Подписка на смену сети: система будит приложение, даже если оно не запущено. */
object Net {
    fun register(c: Context) {
        try {
            val cm = c.getSystemService(ConnectivityManager::class.java)
            val pi = PendingIntent.getBroadcast(
                c, 7, Intent(c, NetChangeReceiver::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
            )
            try { cm.unregisterNetworkCallback(pi) } catch (ignored: Exception) {}
            val req = NetworkRequest.Builder()
                .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET).build()
            cm.registerNetworkCallback(req, pi)
        } catch (ignored: Exception) {
        }
    }
}

class NetChangeReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        Scheduler.checkSoon(c, 4)
    }
}
