package ru.chtootvalilos

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.widget.RemoteViews

class StatusWidget : AppWidgetProvider() {

    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        Net.register(ctx)
        Scheduler.ensure(ctx)
        ids.forEach { render(ctx, mgr, it) }
        Scheduler.checkSoon(ctx, 1)
    }

    override fun onEnabled(ctx: Context) {
        Net.register(ctx)
        Scheduler.ensure(ctx)
        Scheduler.checkSoon(ctx, 1)
    }

    companion object {
        fun updateAll(ctx: Context) {
            val mgr = AppWidgetManager.getInstance(ctx)
            val ids = mgr.getAppWidgetIds(ComponentName(ctx, StatusWidget::class.java))
            ids.forEach { render(ctx, mgr, it) }
        }

        private fun render(ctx: Context, mgr: AppWidgetManager, id: Int) {
            val r = Store.loadReport(ctx)
            val v = RemoteViews(ctx.packageName, R.layout.widget_status)
            val warn = Store.warnMs(ctx)

            var bg = R.drawable.widget_bg_black
            var big = "…"
            var small = "проверяю"
            var fg = Color.WHITE
            var fg2 = 0xCCFFFFFF.toInt()

            if (r != null) {
                when (r.state) {
                    State.GREEN -> {
                        bg = R.drawable.widget_bg_green
                        big = if (r.pingMs > 0) r.pingMs.toString() else "OK"
                        small = if (r.pingMs > 0) (if (r.vpn) "мс • VPN" else "мс") else "всё ок"
                    }
                    State.YELLOW -> {
                        bg = R.drawable.widget_bg_yellow
                        big = if (r.pingMs > 0) r.pingMs.toString() else "!"
                        small = if (r.pingMs > warn) "медленно" else "есть сбои"
                        fg = 0xFF1A1300.toInt()
                        fg2 = 0xCC1A1300.toInt()
                    }
                    State.RED -> {
                        bg = R.drawable.widget_bg_red
                        big = "✕"
                        small = if (r.vpn) "VPN лёг" else "нет связи"
                    }
                    State.BLACK -> {
                        bg = R.drawable.widget_bg_black
                        big = "WL"
                        small = "белый список"
                    }
                }
            }

            v.setInt(R.id.root, "setBackgroundResource", bg)
            v.setTextViewText(R.id.big, big)
            v.setTextViewText(R.id.small, small)
            v.setTextColor(R.id.big, fg)
            v.setTextColor(R.id.small, fg2)

            val pi = PendingIntent.getActivity(
                ctx, 0, Intent(ctx, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            v.setOnClickPendingIntent(R.id.root, pi)
            mgr.updateAppWidget(id, v)
        }
    }
}
