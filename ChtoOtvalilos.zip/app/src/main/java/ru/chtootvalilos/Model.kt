package ru.chtootvalilos

import org.json.JSONArray
import org.json.JSONObject

enum class State { GREEN, YELLOW, RED, BLACK }
enum class Lvl { OK, WARN, FAIL, SKIP }

data class Row(val title: String, val lvl: Lvl, val detail: String)

data class Report(
    val state: State,
    val headline: String,
    val pingMs: Int,
    val vpn: Boolean,
    val rows: List<Row>,
    val advice: List<String>,
    val time: Long
) {
    fun toJson(): String {
        val o = JSONObject()
        o.put("state", state.name)
        o.put("headline", headline)
        o.put("ping", pingMs)
        o.put("vpn", vpn)
        o.put("time", time)
        val ra = JSONArray()
        rows.forEach { ra.put(JSONObject().put("t", it.title).put("l", it.lvl.name).put("d", it.detail)) }
        o.put("rows", ra)
        val aa = JSONArray()
        advice.forEach { aa.put(it) }
        o.put("advice", aa)
        return o.toString()
    }

    companion object {
        fun fromJson(s: String): Report? = try {
            val o = JSONObject(s)
            val ra = o.getJSONArray("rows")
            val rows = (0 until ra.length()).map {
                val x = ra.getJSONObject(it)
                Row(x.getString("t"), Lvl.valueOf(x.getString("l")), x.getString("d"))
            }
            val aa = o.getJSONArray("advice")
            val adv = (0 until aa.length()).map { aa.getString(it) }
            Report(
                State.valueOf(o.getString("state")), o.getString("headline"),
                o.getInt("ping"), o.getBoolean("vpn"), rows, adv, o.getLong("time")
            )
        } catch (e: Exception) {
            null
        }
    }
}
