package ru.chtootvalilos

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.WindowInsets
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {

    private val BG = 0xFF0B0D12.toInt()
    private val CARD = 0xFF151A23.toInt()
    private val WHITE = 0xFFFFFFFF.toInt()
    private val GRAY = 0xFF9AA3B2.toInt()

    private lateinit var scroll: ScrollView
    private lateinit var dyn: LinearLayout
    private lateinit var subtitle: TextView
    private lateinit var btn: Button
    private var busy = false

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun tv(t: String, sp: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = t
        textSize = sp
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun lp(top: Int = 0) = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
    ).apply { topMargin = dp(top) }

    private fun round(color: Int, r: Int = 18) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(r).toFloat()
    }

    private fun stateColors(s: State): IntArray = when (s) {
        State.GREEN -> intArrayOf(0xFF4ADE80.toInt(), 0xFF15803D.toInt())
        State.YELLOW -> intArrayOf(0xFFFDE047.toInt(), 0xFFCA8A04.toInt())
        State.RED -> intArrayOf(0xFFF87171.toInt(), 0xFF991B1B.toInt())
        State.BLACK -> intArrayOf(0xFF2A2A30.toInt(), 0xFF000000.toInt())
    }

    private fun lvlColor(l: Lvl): Int = when (l) {
        Lvl.OK -> 0xFF22C55E.toInt()
        Lvl.WARN -> 0xFFFACC15.toInt()
        Lvl.FAIL -> 0xFFEF4444.toInt()
        Lvl.SKIP -> 0xFF6B7280.toInt()
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)

        scroll = ScrollView(this).apply { setBackgroundColor(BG) }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(32))
        }
        scroll.addView(col)

        col.addView(tv("Что отвалилось", 28f, WHITE, true))
        subtitle = tv("проверяю…", 13f, GRAY)
        col.addView(subtitle)

        btn = Button(this).apply {
            text = "Проверить сейчас"
            setOnClickListener { runCheck() }
        }
        col.addView(btn, lp(12))

        dyn = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(dyn, lp(8))

        col.addView(settingsBlock(), lp(20))

        setContentView(scroll)
        scroll.setOnApplyWindowInsetsListener { v, ins ->
            val bars = ins.getInsets(WindowInsets.Type.systemBars())
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            WindowInsets.CONSUMED
        }

        Net.register(this)
        Scheduler.ensure(this)
        Store.loadReport(this)?.let { show(it) }
        runCheck()
    }

    private fun runCheck() {
        if (busy) return
        busy = true
        btn.isEnabled = false
        btn.text = "Проверяю… (до 30 секунд)"
        val app = applicationContext
        Thread {
            val r = try { Checker.run(app) } catch (e: Exception) { null }
            if (r != null) {
                Store.saveReport(app, r)
                StatusWidget.updateAll(app)
            }
            runOnUiThread {
                busy = false
                btn.isEnabled = true
                btn.text = "Проверить сейчас"
                if (r != null) show(r) else Toast.makeText(this, "Проверка не удалась", Toast.LENGTH_SHORT).show()
            }
        }.start()
    }

    private fun show(r: Report) {
        dyn.removeAllViews()
        subtitle.text = "Проверено в " + SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date(r.time))

        // большая карточка статуса
        val cols = stateColors(r.state)
        val dark = r.state == State.YELLOW
        val txt = if (dark) 0xFF1A1300.toInt() else WHITE
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(20))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, cols).apply {
                cornerRadius = dp(24).toFloat()
                if (r.state == State.BLACK) setStroke(dp(1), 0x66FFFFFF)
            }
        }
        card.addView(tv(r.headline, 20f, txt, true))
        if (r.pingMs > 0) card.addView(tv("Отклик: ${r.pingMs} мс" + if (r.vpn) " (через VPN)" else "", 14f, txt))
        dyn.addView(card, lp())

        // уровни проверки
        dyn.addView(tv("Уровни проверки", 16f, WHITE, true), lp(20))
        val rowsBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = round(CARD)
            setPadding(dp(14), dp(6), dp(14), dp(6))
        }
        r.rows.forEach { rowsBox.addView(rowView(it)) }
        dyn.addView(rowsBox, lp(8))

        // рекомендации
        dyn.addView(tv("Что делать", 16f, WHITE, true), lp(20))
        val advBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = round(CARD)
            setPadding(dp(14), dp(10), dp(14), dp(10))
        }
        r.advice.forEach { a ->
            val t = tv("• $a", 14f, 0xFFE5E7EB.toInt())
            t.setPadding(0, dp(4), 0, dp(4))
            advBox.addView(t)
        }
        dyn.addView(advBox, lp(8))
    }

    private fun rowView(r: Row): View {
        val h = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(8), 0, dp(8))
        }
        val dot = tv("●", 16f, lvlColor(r.lvl)).apply { setPadding(0, 0, dp(10), 0) }
        val v = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        v.addView(tv(r.title, 15f, WHITE, true))
        v.addView(tv(r.detail, 13f, GRAY))
        h.addView(dot)
        h.addView(v, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        return h
    }

    private fun field(hint: String, value: String, numeric: Boolean): EditText = EditText(this).apply {
        setHint(hint)
        setText(value)
        setTextColor(WHITE)
        setHintTextColor(0xFF6B7280.toInt())
        setSingleLine(true)
        inputType = if (numeric) InputType.TYPE_CLASS_NUMBER else InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
    }

    private fun settingsBlock(): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = round(CARD)
            setPadding(dp(14), dp(12), dp(14), dp(14))
        }
        box.addView(tv("Проверка вашего сервера (необязательно)", 16f, WHITE, true))
        box.addView(
            tv(
                "Укажите адрес и порт из вашей vless-ссылки и sni= — приложение проверит TCP, TLS и «заморозку после 16 КБ» напрямую, мимо VPN.",
                12f, GRAY
            )
        )
        val host = field("Адрес сервера (IP или домен)", Store.host(this), false)
        val port = field("Порт", Store.port(this).toString(), true)
        val sni = field("SNI (из параметра sni=)", Store.sni(this), false)
        val warn = field("Порог «медленно», мс", Store.warnMs(this).toString(), true)
        box.addView(host, lp(8)); box.addView(port, lp()); box.addView(sni, lp()); box.addView(warn, lp())
        val save = Button(this).apply {
            text = "Сохранить"
            setOnClickListener {
                Store.saveServer(
                    this@MainActivity, host.text.toString(),
                    port.text.toString().toIntOrNull() ?: 443,
                    sni.text.toString(),
                    warn.text.toString().toIntOrNull() ?: 900
                )
                Toast.makeText(this@MainActivity, "Сохранено", Toast.LENGTH_SHORT).show()
            }
        }
        box.addView(save, lp(6))
        box.addView(
            tv(
                "Виджет 1×1: зелёный — всё хорошо, жёлтый — медленно или сбои, красный — отвалилось, чёрный — белый список. Нажатие открывает это окно.",
                12f, GRAY
            ).apply { gravity = Gravity.START }, lp(10)
        )
        return box
    }
}
